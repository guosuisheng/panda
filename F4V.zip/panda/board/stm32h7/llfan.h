void EXTI2_IRQ_Handler(void) { }
void fan_init(void){ }
