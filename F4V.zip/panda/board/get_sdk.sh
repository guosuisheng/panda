#!/bin/bash
sudo apt-get install dfu-util gcc-arm-none-eabi python3-pip
sudo pip install libusb1 pycryptodome requests
