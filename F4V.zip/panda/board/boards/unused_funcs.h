void unused_set_gps_mode(uint8_t mode) {
  UNUSED(mode);
}

void unused_usb_power_mode_tick(uint32_t uptime) {
  UNUSED(uptime);
}

void unused_set_ir_power(uint8_t percentage) {
  UNUSED(percentage);
}

void unused_set_fan_power(uint8_t percentage) {
  UNUSED(percentage);
}

void unused_set_phone_power(bool enabled) {
  UNUSED(enabled);
}

void unused_set_clock_source_mode(uint8_t mode) {
  UNUSED(mode);
}

void unused_set_siren(bool enabled) {
  UNUSED(enabled);
}

uint32_t unused_read_current(void) {
  return 0U;
}
