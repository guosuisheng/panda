#!/usr/bin/env python3
import argparse
from typing import List, Optional
from tqdm import tqdm
from panda import Panda
from panda.python.uds import UdsClient, MessageTimeoutError, NegativeResponseError, InvalidSubAddressError, \
                             SESSION_TYPE, DATA_IDENTIFIER_TYPE

import binascii,struct
from hexdump import hexdump
import time

#from opendbc.can.packer import CANPacker
def crc(input):
  r=0x01 # bus number
  for b in input:
    r = int(r) + int(b)
  crc =r & 0xff
  #crc = r
  crc = crc.to_bytes(1,'little')
  print(input.hex(),crc.hex() )
  return input+crc

def mcmd(sends):
  print("Sends",sends.hex())
  addr=0x01
  rout=panda.can_send(addr, sends, 0)
  time.sleep(0.1)
  ret=panda.can_recv()
  if len(ret)>0:
    for x in ret:
      opcode, bs, t1, t4 = x
      print("=",x,bs,t1.hex(),t4)



if __name__ == "__main__":
  parser = argparse.ArgumentParser()
  parser.add_argument("--rxoffset", default="")
  parser.add_argument("--nonstandard", action="store_true")
  parser.add_argument("--no-obd", action="store_true", help="Bus 1 will not be multiplexed to the OBD-II port")
  parser.add_argument("--debug", action="store_true")
  parser.add_argument("--addr")
  parser.add_argument("--sub_addr", "--subaddr", help="A hex sub-address or `scan` to scan the full sub-address range")
  parser.add_argument("--bus")
  parser.add_argument('-s', '--serial', help="Serial number of panda to use")
  args = parser.parse_args()

  if args.addr:
    addrs = [int(args.addr, base=16)]
  else:
    addrs = [0x700 + i for i in range(256)]
    addrs += [0x18da0000 + (i << 8) + 0xf1 for i in range(256)]
  results = {}

  sub_addrs: List[Optional[int]] = [None]
  if args.sub_addr:
    if args.sub_addr == "scan":
      sub_addrs = list(range(0xff + 1))
    else:
      sub_addrs = [int(args.sub_addr, base=16)]
      if sub_addrs[0] > 0xff:  # type: ignore
        print(f"Invalid sub-address: 0x{sub_addrs[0]:X}, needs to be in range 0x0 to 0xff")
        parser.print_help()
        exit()

  uds_data_ids = {}
  for std_id in DATA_IDENTIFIER_TYPE:
    uds_data_ids[std_id.value] = std_id.name
  if args.nonstandard:
    for uds_id in range(0xf100, 0xf180):
      uds_data_ids[uds_id] = "IDENTIFICATION_OPTION_VEHICLE_MANUFACTURER_SPECIFIC_DATA_IDENTIFIER"
    for uds_id in range(0xf1a0, 0xf1f0):
      uds_data_ids[uds_id] = "IDENTIFICATION_OPTION_VEHICLE_MANUFACTURER_SPECIFIC"
    for uds_id in range(0xf1f0, 0xf200):
      uds_data_ids[uds_id] = "IDENTIFICATION_OPTION_SYSTEM_SUPPLIER_SPECIFIC"

  panda_serials = Panda.list()
  if args.serial is None and len(panda_serials) > 1:
    print("\nMultiple pandas found, choose one:")
    for serial in panda_serials:
      with Panda(serial) as panda:
        print(f"  {serial}: internal={panda.is_internal()}")
    print()
    parser.print_help()
    exit()

  panda = Panda()

  #panda.set_power_save(False)

  h=panda.health()
  print(h)

  #panda.set_power_save(False)

  panda.set_can_speed_kbps(0, 500)
  #panda.set_can_speed_kbps(1, 500)
  #panda.set_can_speed_kbps(2, 500)


  panda.set_safety_mode(Panda.SAFETY_ALLOUTPUT)
  #panda.set_safety_mode(Panda.SAFETY_)

  cmd=b'\x30'
  fcmd=crc(cmd)
  print(fcmd.hex())
  mcmd(b'\x30\x31')
  '''
  cmd=b'\x31'
  fcmd=crc(cmd)
  print(fcmd.hex())
  mcmd(fcmd)

  cmd=b'\x32'
  fcmd=crc(cmd)
  print(fcmd.hex())
  mcmd(fcmd)

  time.sleep(1)

  #cmd=b'\xfe\x02\x58\x02\x00\x40\x00'
  #fcmd=crc(cmd)
  #print(fcmd.hex())
  #mcmd(fcmd)

  #cmd=b'\xfd\x01\x40\x02\x00\xfa\x00'
  #fcmd=crc(cmd)
  #print(fcmd.hex())
  #mcmd(fcmd)

  cmd=b'\xf1'
  fcmd=crc(cmd)
  print(fcmd.hex())
  mcmd(fcmd)
  '''

  #cmd=b'\xf6\x01\x40\x02'
  #fcmd=crc(cmd)
  #print(fcmd.hex())
  #mcmd(fcmd)


  #cmd=b'\xfd\x01\x40\x02\x00\xfa\x00'
  #fcmd=crc(cmd)
  #print(fcmd.hex())
  #mcmd(fcmd)



  #panda.can_recv()
  #addr=0x01
  #sends=b'\x30\x31'
  #sends=crc(b'\x01\xfd\x01\x40\x02\x00\xfa')
  #print("input",sends.hex())
  #sends=b'\x31\x32'
  #panda.can_send(0x1aa, "message", 0)
  #addr=0x01
  #sends="message"
  # sends=b'\xF6\x01\x40\x02\x3A'
  #print(binascii.hexlify(sends))
  #n=10
  #for i in range(1,n):
  #  rout=panda.can_send(addr, sends, 0)

  #  time.sleep(0.2)
  #  ret=panda.can_recv()
  #  time.sleep(0.2)
  #opcode, bs, t1, t4 = ret[0]
  #  print(ret,rout)
    #ret=panda.can_recv()
  #opcode, bs, t1, t4 = ret[0]
    #print(ret,rout)
  #while True:
    #can_recv = panda.can_recv()
  #  if len(can_recv)>0:
    #print(can_recv)


    #rout=panda.can_send(addr, sends, 0)
    #ret=panda.can_recv()
    #opcode, bs, t1, t4 = ret[0]
    #print(opcode,bs,t1,t4)
    #print(binascii.hexlify(t1) , hex(t4))

    #rout=panda.can_send(addr, sends, 1)
    #time.sleep(0.1)
    #ret=panda.can_recv()
    #if len(ret)>0:
    #  for x in ret:
    #    opcode, bs, t1, t4 = x
    #    print("=",t1.hex(),x)
    #ret=panda.can_recv()
    #if len(ret)>0:
    #  for x in ret:
    #    opcode, bs, t1, t4 = x
    #    print("=",binascii.hexlify(t1),x)

  #panda.can_send(addr, sends, 1)
  #ret=panda.can_recv()
    #opcode, bs, t1, t4 = ret[0]
    #print(opcode,bs,t1,t4)
    #print(binascii.hexlify(t1) , hex(t4))

  #print(binascii.hexlify(t1) , hex(t4))

  #print(ret)
  #time.sleep(1)
  #ret=panda.can_recv()
  #print(ret)
  ret=panda.can_recv()
  print(ret)
  h=panda.can_health(0)
  print(0,h)
  h=panda.can_health(1)
  print(1,h)

  h=panda.can_health(2)
  print(2,h)

  h=panda.health()
  print(h)


