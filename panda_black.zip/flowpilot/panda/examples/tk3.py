import tkinter as tk
from tkinter import messagebox

from panda import Panda
from panda.python.uds import UdsClient, MessageTimeoutError, NegativeResponseError, InvalidSubAddressError, \
                             SESSION_TYPE, DATA_IDENTIFIER_TYPE

import binascii,struct
from hexdump import hexdump
import time


import mks

def hex_to_int():
    try:
        hex_value = hex_entry.get()
        int_value = int(hex_value, 16)
        int_entry.delete(0, tk.END)
        int_entry.insert(0, str(int_value))
    except ValueError:
        messagebox.showerror("Invalid input", "Please enter a valid hexadecimal value")

def run():
    hex_string=hex_entry.get()
    byte_array = bytes.fromhex(hex_string)
    rt=mks.mcmd_crc(byte_array)
    int_entry.delete(0, tk.END)
    int_entry.insert(0, rt.hex())


def clear_entries():
    hex_entry.delete(0, tk.END)
    int_entry.delete(0, tk.END)

# Create the main window
root = tk.Tk()
root.title("Hex to Int Converter")

# Create and place widgets
hex_label = tk.Label(root, text="Hex Value:")
hex_label.grid(row=0, column=0, padx=10, pady=5)

hex_entry = tk.Entry(root)
hex_entry.grid(row=0, column=1, padx=10, pady=5)

# second

int_label = tk.Label(root, text="Int Value:")
int_label.grid(row=1, column=0, padx=10, pady=5)

int_entry = tk.Entry(root,width=40)
int_entry.grid(row=1, column=1, padx=10, pady=5)

#thirst 

cmd_label = tk.Label(root, text="cmd Value:")
cmd_label.grid(row=2, column=0, padx=10, pady=5)

cmd_entry = tk.Entry(root)
cmd_entry.grid(row=2, column=1, padx=10, pady=5)

#result
i=3
result_label = tk.Label(root, text="result Value:")
result_label.grid(row=i, column=0, padx=10, pady=5)

result_entry = tk.Entry(root,width=30)
result_entry.grid(row=i, column=1, padx=10, pady=5)

#
i=i+1
convert_button = tk.Button(root, text="Convert", command=hex_to_int)
convert_button.grid(row=i, column=0, padx=10, pady=10)

clear_button = tk.Button(root, text="Run", command=run)
clear_button.grid(row=i, column=1, padx=10, pady=10)

exit_button = tk.Button(root, text="Exit", command=root.destroy)
exit_button.grid(row=i, column=2, columnspan=3, pady=10)
#



# Start the main event loop
root.mainloop()
